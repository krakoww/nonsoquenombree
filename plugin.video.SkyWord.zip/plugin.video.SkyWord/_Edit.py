import xbmcaddon

MainBase = 'https://goo.gl/MdioHt'
addon = xbmcaddon.Addon('plugin.video.SkyWord')
